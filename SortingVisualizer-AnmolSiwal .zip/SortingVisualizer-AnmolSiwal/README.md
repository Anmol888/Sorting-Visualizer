
<h3 align="center">Sorting.Visualizer</h3>

**_Sorting.Visualizer is a web application for visualizing a different sorting algorithms like_**
1. Selection Sort.
2. Bubble Sort.
3. Insertion Sort.
4. Merge Sort.
5. Quick Sort.
6. Heap Sort.
